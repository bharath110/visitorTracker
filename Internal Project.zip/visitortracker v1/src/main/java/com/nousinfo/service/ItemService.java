

package com.nousinfo.service;
        import com.nousinfo.bean.Item;

public interface ItemService {

    Item saveItem(Item itemDetails);
}
